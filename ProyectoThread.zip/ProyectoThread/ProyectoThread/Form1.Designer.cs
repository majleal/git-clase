﻿namespace ProyectoThread
{
    partial class Form1
    {
        /// <summary>
        /// Variable del diseñador necesaria.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Limpiar los recursos que se estén usando.
        /// </summary>
        /// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Código generado por el Diseñador de Windows Forms

        /// <summary>
        /// Método necesario para admitir el Diseñador. No se puede modificar
        /// el contenido de este método con el editor de código.
        /// </summary>
        private void InitializeComponent()
        {
            this.btReproducir = new System.Windows.Forms.Button();
            this.pBox1 = new System.Windows.Forms.PictureBox();
            this.btDetener = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // btReproducir
            // 
            this.btReproducir.Location = new System.Drawing.Point(80, 190);
            this.btReproducir.Name = "btReproducir";
            this.btReproducir.Size = new System.Drawing.Size(109, 39);
            this.btReproducir.TabIndex = 0;
            this.btReproducir.Text = "Reproducir";
            this.btReproducir.UseVisualStyleBackColor = true;
            this.btReproducir.Click += new System.EventHandler(this.btReproducir_Click);
            // 
            // pBox1
            // 
            this.pBox1.Location = new System.Drawing.Point(12, 12);
            this.pBox1.Name = "pBox1";
            this.pBox1.Size = new System.Drawing.Size(434, 161);
            this.pBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pBox1.TabIndex = 1;
            this.pBox1.TabStop = false;
            // 
            // btDetener
            // 
            this.btDetener.Location = new System.Drawing.Point(277, 190);
            this.btDetener.Name = "btDetener";
            this.btDetener.Size = new System.Drawing.Size(102, 39);
            this.btDetener.TabIndex = 2;
            this.btDetener.Text = "Detener";
            this.btDetener.UseVisualStyleBackColor = true;
            this.btDetener.Click += new System.EventHandler(this.BtDetener_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(458, 241);
            this.Controls.Add(this.btDetener);
            this.Controls.Add(this.pBox1);
            this.Controls.Add(this.btReproducir);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pBox1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btReproducir;
        private System.Windows.Forms.PictureBox pBox1;
        private System.Windows.Forms.Button btDetener;
    }
}

