﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using System.Threading;

namespace ProyectoThread
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }

        public void img()
        {
            pBox1.Enabled = true;
            pBox1.Image = Image.FromFile("/ProyectoThread/stickman.gif");
        }

        public void Reproduce()
        {
            SoundPlayer sonido = new SoundPlayer();
            sonido.SoundLocation = "/ProyectoThread/Calypso.wav";
            sonido.Play();
        }

        private void btReproducir_Click(object sender, EventArgs e)
        {
            Thread animacion = new Thread(Reproduce);
            animacion.Start();
            img();
        }

        private void BtDetener_Click(object sender, EventArgs e)
        {
            SoundPlayer sonido = new SoundPlayer();
            sonido.SoundLocation = "C:/Users/52744/Music/Calypso.wav";
            sonido.Stop();
            pBox1.Enabled = false;
        }
    }
}
